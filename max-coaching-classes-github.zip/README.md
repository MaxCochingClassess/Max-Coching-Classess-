# MAX Coaching Classes — GitHub Pages Website

## Publish on GitHub Pages
1. Create a new GitHub repository, for example `max-coaching-classes`.
2. Upload `index.html`, `style.css`, `script.js` and the `assets` folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. GitHub will provide the live website URL.

### Contact
Phone/WhatsApp: 7268807285
Location: Vill & Post Odar, Pindra, Varanasi, Uttar Pradesh
